const mongoose = require("mongoose");
const zoneSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      unique: true,
    },
    location: {
      type: {
        type: String,
        enum: ["Point"],
        default: "Point",
      },
      coordinates: {
        type: [Number],
        required: [
          true,
          "A street light must have coordinates (longitude, latitude)",
        ],
      },
    },
    dateTimes: [
      {
        startDateTime: {
          type: Date,
        },
        endDateTime: {
          type: Date,
        },
        BrightnessLevel: {
          type: Number,
          required: [true, "A Light must have brightness"],
          default: 0,
        },
      },
    ],
    BrightnessLevel: {
      type: Number,
      default: 0,
    },
    isPoweredOn: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
  }
);
zoneSchema.pre("save", function (next) {
  if (this.BrightnessLevel === 0) {
    this.isPoweredOn = false;
  } else if (!this.isPoweredOn) {
    this.BrightnessLevel = 0;
  }
  next();
});
zoneSchema.index({ location: "2dsphere" });
module.exports = mongoose.model("zonesetting", zoneSchema);
