const ZoneSetting = require("../models/zonesettings");

exports.createZoneSetting = async (req, res) => {
  try {
    const { name, location, dateTimes, BrightnessLevel, isPoweredOn } =
      req.body;

    if (!location || !location.coordinates) {
      return res.status(400).json({
        message: "Location and coordinates are required",
      });
    }

    const newZoneSetting = new ZoneSetting({
      name,
      location,
      dateTimes,
      BrightnessLevel,
      isPoweredOn,
    });

    const savedZoneSetting = await newZoneSetting.save();

    res.status(201).json({
      success: true,
      message: "Zone setting created successfully",
      data: savedZoneSetting,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error creating zone setting",
      error: error.message,
    });
  }
};

exports.getAllZoneSettings = async (req, res) => {
  try {
    const zoneSettings = await ZoneSetting.find();
    res.status(200).json({
      success: true,
      message: "Zone settings fetched successfully",
      data: zoneSettings,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error fetching zone settings",
      error: error.message,
    });
  }
};

exports.getZoneSettingById = async (req, res) => {
  try {
    const zoneSetting = await ZoneSetting.findById(req.params.id);
    if (!zoneSetting) {
      return res.status(404).json({
        message: "Zone setting not found",
      });
    }
    res.status(200).json({
      success: true,
      message: "Zone setting fetched successfully",
      data: zoneSetting,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error fetching zone setting",
      error: error.message,
    });
  }
};

exports.updateZoneSetting = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, location, dateTimes, BrightnessLevel, isPoweredOn } =
      req.body;

    const updatedZoneSetting = await ZoneSetting.findByIdAndUpdate(
      id,
      { name, location, dateTimes, BrightnessLevel, isPoweredOn },
      { new: true, runValidators: true }
    );

    if (!updatedZoneSetting) {
      return res.status(404).json({
        message: "Zone setting not found",
      });
    }

    res.status(200).json({
      success: true,
      message: "Zone setting updated successfully",
      data: updatedZoneSetting,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error updating zone setting",
      error: error.message,
    });
  }
};

exports.deleteZoneSetting = async (req, res) => {
  try {
    const { id } = req.params;
    const deletedZoneSetting = await ZoneSetting.findByIdAndDelete(id);
    if (!deletedZoneSetting) {
      return res.status(404).json({
        message: "Zone setting not found",
      });
    }
    res.status(200).json({
      success: true,
      message: "Zone setting deleted successfully",
      data: deletedZoneSetting,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error deleting zone setting",
      error: error.message,
    });
  }
};
