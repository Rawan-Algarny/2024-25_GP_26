// const mongoose = require("mongoose");

// const LightSchema = new mongoose.Schema(
//   {
//     lightid: {
//       type: String,
//     },
//     zone: {
//       type: String,
//     },
//     address: {
//       type: String,
//     },
//     status: {
//       type: String,
//       enum: ["Active", "Inactive"],
//       default: "Inactive",
//     },
//     applyZoneSetting: {
//       type: Boolean,
//     },
//     applyControllingSetting: {
//       type: Boolean,
//     },
//     // startTime: {
//     //   type: String,
//     //   required: function () {
//     //     return this.allowusertocontrollsetting;
//     //   },
//     // },
//     // endTime: {
//     //   type: String,
//     //   required: function () {
//     //     return this.allowusertocontrollsetting;
//     //   },
//     // },
//     startDateTime: {
//       type: Date,
//       required: function () {
//         return this.allowusertocontrollsetting;
//       },
//     },
//     endDateTime: {
//       type: Date,
//       required: function () {
//         return this.allowusertocontrollsetting;
//       },
//     },
//     isOn: {
//       type: Boolean,
//     },
//     brightness: {
//       type: Number,
//       min: 0,
//       max: 100,
//       default: 70,
//       // required: function () {
//       //   return this.allowusertocontrollsetting;
//       // },
//     },
//   },
//   {
//     timestamps: true,
//   }
// );

// module.exports = mongoose.model("lights", LightSchema);
