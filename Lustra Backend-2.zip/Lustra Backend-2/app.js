const express = require("express");
const connectDB = require("./config/db.config");
const http = require("http");
const app = express();
const cors = require("cors");

//App Use
app.use(express.json());
app.use(cors());

//Routes
const LightRouter = require("./routes/light.route");

//app.use

app.use("/api/v1", LightRouter);
const start = async () => {
  try {
    await connectDB(
      "mongodb+srv://hend:FHDuyUyFARKjwBUY@smart-streetlight-app-c.2cgvs.mongodb.net/Lustra"
    );
    console.log("DB Connected");
  } catch (error) {
    console.log(error);
  }
};

let server;

server = http.createServer(app);

const port = process.env.PORT || 8900;
server.listen(port, () =>
  console.log(`Server is running and listenning on ${port}`)
);

start();
