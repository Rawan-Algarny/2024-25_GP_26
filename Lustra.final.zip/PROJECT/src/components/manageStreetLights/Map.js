import PropTypes from "prop-types";
import { GoogleMap, MarkerF } from "@react-google-maps/api";
import React, { memo, useState } from "react";

const styles = {
  container: {
    width: "100%",
    height: "400px",
  },
};

const MapComponent = ({ data, mapCenter }) => {
  const [map, setMap] = useState(null);

  const defaultMapCenter = {
    lat: 24.7136,
    lng: 46.6753,
  };

  const centerToShow = mapCenter || defaultMapCenter;

  console.log("data", data);

  return (
    <div className="w-full">
      <div className="w-full">
        <GoogleMap
          onLoad={setMap}
          id="shapes-example"
          mapContainerStyle={styles.container}
          center={centerToShow}
          zoom={14}
        >
          {/* Render markers based on data */}
          {data?.length > 0 &&
            data?.map(([lng, lat], index) => (
              <MarkerF
                key={index}
                position={{ lat: lat, lng: lng }}
                // icon={{
                //   url: "http://maps.google.com/mapfiles/ms/icons/white-dot.png",
                // }}
              />
            ))}
        </GoogleMap>
      </div>
    </div>
  );
};

MapComponent.propTypes = {
  data: PropTypes.arrayOf(
    PropTypes.arrayOf(PropTypes.number.isRequired).isRequired
  ).isRequired,
  mapCenter: PropTypes.shape({
    lat: PropTypes.number.isRequired,
    lng: PropTypes.number.isRequired,
  }),
};

export default memo(MapComponent);
