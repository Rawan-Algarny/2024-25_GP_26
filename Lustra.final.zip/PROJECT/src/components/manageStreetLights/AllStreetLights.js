import React, { useEffect, useState } from "react";
import { Modal } from "antd";
import { Switch, message, Checkbox } from "antd";
import CustomTable from "../common/CustomTable";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import DefaultLayout from "../header";
import Svgs from "../../assets/svgs";
import {
  deleteLight,
  getAllLights,
  toggleLight,
} from "../../services/street-light";
import { useNavigate } from "react-router-dom";
import Map from "./Map";

const AllStreetLights = () => {
  const [lights, setLights] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedRow, setSelectedRow] = useState(null);
  const [refetch, setRefetch] = useState(0);

  const [isOn, setIsOn] = useState(false);

  const handleToggle = () => {
    setIsOn((prevState) => !prevState);
  };

  const navigate = useNavigate();

  console.log(
    "lights",
    lights?.map((item) => item?.location?.coordinates)
  );

  useEffect(() => {
    getAllLights().then((res) => {
      setLights(res.data);
    });
  }, [refetch]);

  // Define table headers
  const headers = [
    "ID",
    "Status",
    // "Streetlight",
    "Zone",
    "Location",
    "On / Off",
    "Brightness",
    "Delete",
    "Update",
    "Zone Setting",
    "Controlling Profile",
  ];

  const showModal = () => {
    setIsModalOpen(true);
  };

  const handleOk = async () => {
    try {
      await deleteLight(selectedRow._id);
      setRefetch((prev) => prev + 1);
      setIsModalOpen(false);
      toast.success("Street light deleted successfully");
    } catch (error) {
      toast.error("Failed to delete street light");
    }
  };

  const handleCancel = () => {
    setIsModalOpen(false);
  };

  // // State to manage toggles and selections per row
  // const [rows, setRows] = useState([
  //   { id: 1, toggle1: false, toggle2: false, selected: false },
  //   { id: 2, toggle1: false, toggle2: false, selected: false },
  //   { id: 3, toggle1: false, toggle2: false, selected: false },
  //   { id: 4, toggle1: false, toggle2: false, selected: false },
  // ]);

  const [selectAll, setSelectAll] = useState(false);

  const handleToggleChange = (rowId, toggleKey) => {
    // setRows((prevRows) =>
    //   prevRows.map((row) =>
    //     row.id === rowId ? { ...row, [toggleKey]: !row[toggleKey] } : row
    //   )
    // );
  };

  // const handleRowSelect = (rowId) => {
  // setRows((prevRows) =>
  //   prevRows.map((row) =>
  //     row.id === rowId ? { ...row, selected: !row.selected } : row
  //   )
  // );
  // };

  const handleSelectAll = () => {
    setSelectAll(!selectAll);
    // setRows((prevRows) =>
    //   prevRows.map((row) => ({ ...row, selected: !selectAll }))
    // );
  };

  // Custom Yes/No Toggle component
  const YesNoToggle = ({ checked, onChange, isdisabled }) => (
    <Switch
      checked={checked}
      checkedChildren="Yes"
      unCheckedChildren="No"
      disabled={isdisabled}
      onChange={onChange}
      style={{
        width: 60,
        backgroundColor: checked ? "#1890ff" : "#333",
        color: "#fff",
      }}
    />
  );

  const data = lights.map((row) => {
    return [
      <div className="flex gap-2 items-center">
        {/* <Checkbox
          checked={row.selected}
          onChange={() => handleRowSelect(row.id)}
        /> */}
        <p>{row.lightid}</p>
      </div>,
      row.status,
      // row.address,
      row?.zone,
      <p>{row.address}</p>,
      // <span>
      //   <Svgs.LocationIcon />
      // </span>,

      <p>{row?.isOn ? "ON" : "OFF"}</p>, // <Switch //   value={row.isOn}
      //   onChange={() => {
      //     toggleLight(row._id).then((res) => {
      //       console.log("res", res);
      //       setRefetch((prev) => prev + 1);
      //     });
      //   }}
      // />,
      `${
        row.applyControllingSetting
          ? row.dateTimes?.[0]?.dateTimes?.[0].BrightnessLevel ?? 0
          : row.brightness
      }%`,
      <div
        style={{ cursor: "pointer" }}
        onClick={() => {
          setSelectedRow(row);
          showModal();
        }}
      >
        <Svgs.DeleteIcon />
      </div>,
      <div
        style={{ cursor: "pointer" }}
        onClick={() =>
          navigate("/update-lights", {
            state: {
              light: row,
            },
          })
        }
      >
        <Svgs.EditIcon />
      </div>,
      <p>{row?.applyZoneSetting ? "Applied" : "Not Applied"}</p>,
      // <YesNoToggle
      //   isdisabled={false}
      //   checked={row.applyZoneSetting}
      //   onChange={() => handleToggleChange(row.id, "toggle1")}
      // />,
      <p>{row?.applyControllingSetting ? "Applied" : "Not Applied"}</p>,

      // <YesNoToggle
      //   isdisabled={false}
      //   checked={row.applyControllingSetting}
      //   onChange={(e) => {
      //     handleToggleChange(row.id, "toggle2");
      //   }}
      // />,
    ];
  });

  return (
    <DefaultLayout>
      <div className="overflow-auto w-full">
        <div className="flex items-center justify-between">
          <h1 className="font-sans font-medium text-[32px] text-[#393838] mb-8">
            Manage Streetlight{" "}
            <span className="text-base text-[#6C6A6A]">/All Streetlight</span>
          </h1>
          <div className="flex justify-center items-center ">
            <div className="flex items-end gap-8 flex-col md:flex-row">
              <div className="flex flex-col items-start">
                <label className="text-black text-[20px] font-semibold mt-1 text-left">
                  Map View
                </label>
                <div
                  className={`toggle-container mt-3 ${isOn ? "on" : "off"}`}
                  onClick={handleToggle}
                  aria-label="Toggle On/Off"
                >
                  <span className="toggle-option">Off</span>
                  <span className="toggle-option">On</span>
                  <div className="toggle-knob"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="bg-white mt-3 p-6 w-full flex flex-col justify-start items-start">
          <div className="w-full flex justify-between items-center">
            <p className="text-start font-sans font-medium text-[#4C4A4A] text-[24px]">
              All Streetlight
            </p>
            <span className="cursor-pointer">
              <Svgs.UpArrow />
            </span>
          </div>
          <div className="w-full h-[1px] bg-black mt-6 mb-8"></div>
          <div className="w-full border border-[#e6e8ea] rounded-[10px] mt-8">
            {isOn ? (
              <Map data={lights.map((item) => item.location.coordinates)} />
            ) : (
              <CustomTable headers={headers} data={data} />
            )}
          </div>
          {/* <div className="flex gap-2 items-center mt-5">
            <Checkbox checked={selectAll} onChange={handleSelectAll} />
            <p className="font-medium text-[14px] text-black">Select All</p>
          </div> */}
          {/* <button
              className="w-[143px] h-[37.61px] rounded-[4px] text-white font-normal text-[15px] mt-8"
              style={{
                background:
                  "linear-gradient(90deg, #3D68B0 1.67%, #84A8E6 47.17%, #3D68B0 100%)",
              }}
            >
              Delete Selected
            </button> */}
        </div>
      </div>
      <Modal
        title="Delete Street light"
        open={isModalOpen}
        onOk={handleOk}
        onCancel={handleCancel}
        okText="Delete"
        okType="danger"
      >
        <p>Are you sure you want to delete this street light?</p>
      </Modal>
      <ToastContainer limit={1} position="top-right" autoClose={2000} />
    </DefaultLayout>
  );
};

export default AllStreetLights;
