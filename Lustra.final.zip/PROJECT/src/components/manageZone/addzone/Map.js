import PropTypes from "prop-types";
import { Polygon, GoogleMap, Marker } from "@react-google-maps/api";
import React, { memo, useRef, useState, useCallback } from "react";

const styles = {
  container: {
    width: "100%",
    height: "400px",
  },
};

const MapComponent = ({ triangleCoords, setTriangleCoords, mapCenter }) => {
  const [map, setMap] = useState(null);
  const [clickedPosition, setClickedPosition] = useState(null);

  const polygonRef = useRef(null);
  const listenersRef = useRef([]);

  const defaultMapCenter = {
    lat: 24.7136,
    lng: 46.6753,
  };

  const onEdit = useCallback(() => {
    if (polygonRef.current) {
      const nextPath = polygonRef.current
        .getPath()
        .getArray()
        .map((latLng) => ({ lat: latLng.lat(), lng: latLng.lng() }));
      setTriangleCoords(nextPath);
    }
  }, [setTriangleCoords]);

  const onLoad = useCallback(
    (polygon) => {
      polygonRef.current = polygon;
      const path = polygon.getPath();
      listenersRef.current.push(
        path.addListener("set_at", onEdit),
        path.addListener("insert_at", onEdit),
        path.addListener("remove_at", onEdit)
      );
    },
    [onEdit]
  );

  const onUnmount = useCallback(() => {
    listenersRef.current.forEach((listener) => listener.remove());
    polygonRef.current = null;
  }, []);

  const handleMapClick = useCallback(
    (e) => {
      const clickedCoords = { lat: e.latLng.lat(), lng: e.latLng.lng() };
      setClickedPosition(clickedCoords);

      // Update triangleCoords with a new reference
      setTriangleCoords((prevCoords) => [...prevCoords, clickedCoords]);
    },
    [setTriangleCoords]
  );

  const centerToShow = mapCenter || defaultMapCenter;

  return (
    <div className="w-full">
      <div className="w-full">
        <GoogleMap
          onLoad={setMap}
          id="shapes-example"
          mapContainerStyle={styles.container}
          center={centerToShow}
          zoom={14}
          onClick={handleMapClick}
        >
          {clickedPosition && (
            <Marker
              position={clickedPosition}
              icon={{
                url: "http://maps.google.com/mapfiles/ms/icons/white-dot.png",
              }}
            />
          )}
          {triangleCoords?.length > 0 && (
            <Polygon
              editable
              draggable
              path={triangleCoords}
              options={{
                clickable: false,
                strokeColor: "#FFFFFF",
                fillColor: "#FFFFFF",
              }}
              onLoad={onLoad}
              onMouseUp={onEdit}
              onDragEnd={onEdit}
              onUnmount={onUnmount}
            />
          )}
        </GoogleMap>
      </div>
    </div>
  );
};

MapComponent.propTypes = {
  triangleCoords: PropTypes.arrayOf(
    PropTypes.shape({
      lat: PropTypes.number.isRequired,
      lng: PropTypes.number.isRequired,
    })
  ).isRequired,
  setTriangleCoords: PropTypes.func.isRequired,
  mapCenter: PropTypes.shape({
    lat: PropTypes.number.isRequired,
    lng: PropTypes.number.isRequired,
  }),
};

export default memo(MapComponent);
