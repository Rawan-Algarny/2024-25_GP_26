const lightRouter = require("express").Router();

const {
  createLight,
  deleteLight,
  updateLight,
  getAllLights,
  updatePowerStatus,
  getLightsWithZone,
} = require("../controllers/light.controller");

lightRouter.post("/light/create", createLight);
lightRouter.delete("/light/delete/:id", deleteLight);
lightRouter.patch("/light/update/:lightId", updateLight);
lightRouter.get("/light/zone/:id", getLightsWithZone);
lightRouter.get("/light/getall", getAllLights);
lightRouter.patch("/light/togglepower/:lightId", updatePowerStatus);

module.exports = lightRouter;
