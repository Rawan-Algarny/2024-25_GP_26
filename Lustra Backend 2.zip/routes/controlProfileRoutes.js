const express = require("express");

const controlProfileRouter = express.Router();

module.exports = controlProfileRouter;
