const mongoose = require("mongoose");

const streetLightSchema = new mongoose.Schema({
  status: {
    type: String,
    enum: {
      values: ["functioning", "malfunctioning"],
      message: "status is either functioning or malfunctioning",
    },
    default: "functioning",
  },
  lightid: {
    type: String,
  },
  zone: {
    type: mongoose.Types.ObjectId,
    ref: "zonesetting",
  },
  location: {
    type: {
      type: String,
      enum: ["Point"],
      default: "Point",
    },
    coordinates: {
      type: [Number],
      required: [
        true,
        "A street light must have coordinates (longitude, latitude)",
      ],
    },
  },
  address: {
    type: String,
  },
  ApplyZoneSetting: {
    type: Boolean,
    default: false,
  },
  ApplyProfileSetting: {
    type: Boolean,
    default: false,
  },
  controlNodeID: {
    type: mongoose.Schema.ObjectId,
  },
  BrightnessLevel: {
    type: Number,
    default: 0,
  },
  isPoweredOn: {
    type: Boolean,
    default: false,
  },
});

streetLightSchema.pre("save", function (next) {
  if (this.BrightnessLevel === 0) {
    this.isPoweredOn = false;
  } else if (!this.isPoweredOn) {
    this.BrightnessLevel = 0;
  }
  next();
});

streetLightSchema.index({ location: "2dsphere" });
module.exports = mongoose.model("StreetLight", streetLightSchema);
