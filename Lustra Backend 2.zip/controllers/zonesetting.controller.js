const ZoneSetting = require("../models/zonesettings");
const Light = require("../models/streetLightModel");

exports.createZoneSetting = async (req, res) => {
  try {
    const { name, location, dateTimes, BrightnessLevel, isPoweredOn } =
      req.body;
    console.log("========", req.body);
    if (!location || !location.coordinates) {
      return res.status(400).json({
        message: "Location and coordinates are required",
      });
    }
    const FindZone = await ZoneSetting.findOne({ name });
    console.log(FindZone);
    if (FindZone) {
      return res
        .status(400)
        .json({ success: false, message: "Zone Already Exist" });
    }
    const newZoneSetting = await ZoneSetting.create({
      name,
      location,
      dateTimes,
      isPoweredOn,
      BrightnessLevel,
    });

    return res.status(201).json({
      success: true,
      message: "Zone setting created successfully",
      data: newZoneSetting,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Error creating zone setting",
      error: error.message,
    });
  }
};

exports.getAllZoneSettings = async (req, res) => {
  try {
    const zoneSettings = await ZoneSetting.find();
    return res.status(200).json({
      success: true,
      message: "Zone settings fetched successfully",
      data: zoneSettings,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Error fetching zone settings",
      error: error.message,
    });
  }
};

exports.getZoneSettingById = async (req, res) => {
  try {
    const zoneSetting = await ZoneSetting.findById(req.params.id);
    if (!zoneSetting) {
      return res.status(404).json({
        message: "Zone setting not found",
      });
    }
    return res.status(200).json({
      success: true,
      message: "Zone setting fetched successfully",
      data: zoneSetting,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Error fetching zone setting",
      error: error.message,
    });
  }
};

exports.updateZoneSetting = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, location, dateTimes, BrightnessLevel, isPoweredOn } =
      req.body;

    const updatedZoneSetting = await ZoneSetting.findByIdAndUpdate(
      id,
      { name, location, dateTimes, BrightnessLevel, isPoweredOn },
      { new: true, runValidators: true }
    );

    if (!updatedZoneSetting) {
      return res.status(404).json({
        message: "Zone setting not found",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Zone setting updated successfully",
      data: updatedZoneSetting,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Error updating zone setting",
      error: error.message,
    });
  }
};

exports.deleteZoneSetting = async (req, res) => {
  try {
    const { id } = req.params;
    const deletedZoneSetting = await ZoneSetting.findByIdAndDelete(id);
    if (!deletedZoneSetting) {
      return res.status(404).json({
        message: "Zone setting not found",
      });
    }
    return res.status(200).json({
      success: true,
      message: "Zone setting deleted successfully",
      data: deletedZoneSetting,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Error deleting zone setting",
      error: error.message,
    });
  }
};

exports.getZoneInfo = async (req, res) => {
  try {
    const { zoneId } = req.params;

    const zone = await ZoneSetting.findById(zoneId);
    if (!zone) {
      return res.status(404).json({ message: "Zone not found" });
    }

    const lights = await Light.find({ zoneId });

    res.status(200).json({
      success: true,
      data: {
        zone,
        lights,
      },
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
};
