const Light = require("../models/streetLightModel");
const ControlProfile = require("../models/controleProfileSetting");

exports.createLight = async (req, res) => {
  try {
    const {
      id,
      zone,
      address,
      status,
      isOn,
      applyZoneSetting,
      applyControllingSetting,
      dateTimes,
      location,
      brightness,
    } = req.body;
    console.log("=========", req.body);
    if (!zone) {
      return res.status(400).json({
        success: false,
        message: "Please provide zone as well",
      });
    }

    const applyZoneSettings = applyZoneSetting === true;
    const controlSetting = applyControllingSetting === true;

    const BrightnessLevel = isOn ? brightness : 0;
    console.log(BrightnessLevel);
    const newLightData = {
      lightid: id,
      address,
      status,
      zone,
      ApplyZoneSetting: applyZoneSettings,
      ApplyProfileSetting: controlSetting,
      location,
      isPoweredOn: isOn,
      BrightnessLevel,
    };

    const newLight = new Light(newLightData);
    const savedLight = await newLight.save();
    console.log(dateTimes);
    if (controlSetting) {
      const controlProfileData = {
        streetLightId: savedLight._id,
        dateTimes: dateTimes.map((dt) => ({
          startDateTime: dt.startDateTime,
          endDateTime: dt.endDateTime,
          BrightnessLevel: dt.brightness,
        })),
      };

      const newProfile = new ControlProfile(controlProfileData);
      await newProfile.save();
    }

    return res.status(201).json({
      success: true,
      data: savedLight,
      message: "Light created successfully",
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      success: false,
      message: "Server error",
      error: error.message,
    });
  }
};

exports.updateLight = async (req, res) => {
  try {
    const { lightId } = req.params;
    const {
      id,
      zone,
      address,
      status,
      applyZoneSetting,
      applyControllingSetting,
      dateTimes,
      isOn,
      brightness,
    } = req.body;

    const BrightnessLevel = isOn ? brightness : 0;

    const updateData = {
      lightid: id,
      address,
      status,
      BrightnessLevel,
      zone,
      isPoweredOn: isOn,
      ApplyZoneSetting: applyZoneSetting === true,
      ApplyProfileSetting: applyControllingSetting === true,
      location: req.body.location,
    };

    const updatedLight = await Light.findOneAndUpdate(
      { _id: lightId },
      updateData,
      { new: true }
    );

    if (!updatedLight) {
      return res.status(404).json({
        success: false,
        message: "Light not found",
      });
    }

    if (applyControllingSetting) {
      await ControlProfile.findOneAndUpdate(
        { streetLightId: lightId },
        {
          isPoweredON: isOn || false,
          dateTimes: dateTimes.map((dt) => ({
            startDateTime: dt.startDateTime,
            endDateTime: dt.endDateTime,
            BrightnessLevel: dt.brightness,
          })),
        },
        { upsert: true, new: true }
      );
    } else {
      await ControlProfile.findOneAndDelete({ streetLightId: lightId });
    }

    return res.status(200).json({
      success: true,
      message: "Light updated successfully",
      data: updatedLight,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      success: false,
      message: "Server error",
      error: error.message,
    });
  }
};

exports.deleteLight = async (req, res) => {
  try {
    const { id } = req.params;

    const deletedLight = await Light.findByIdAndDelete(id);

    if (!deletedLight) {
      return res.status(404).json({
        success: false,
        message: "Light not found",
      });
    }

    await ControlProfile.findOneAndDelete({ streetLightId: id });

    return res.status(200).json({
      success: true,
      message: "Light deleted successfully",
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      success: false,
      message: "Server error",
      error: error.message,
    });
  }
};

exports.getAllLights = async (req, res) => {
  try {
    const now = new Date().toISOString();

    const lights = await Light.aggregate([
      {
        $lookup: {
          from: "zonesettings",
          localField: "zone",
          foreignField: "_id",
          as: "zoneDetails",
        },
      },
      { $unwind: { path: "$zoneDetails", preserveNullAndEmptyArrays: true } },
      {
        $lookup: {
          from: "controlprofiles",
          localField: "_id",
          foreignField: "streetLightId",
          as: "dateTimes",
        },
      },
      {
        $addFields: {
          activeDateTime: {
            $arrayElemAt: [
              {
                $filter: {
                  input: "$zoneDetails.dateTimes",
                  as: "dateTime",
                  cond: {
                    $and: [
                      { $gte: [{ $toDate: "$$dateTime.startDateTime" }, now] },
                      // { $lte: [{ $toDate: "$$dateTime.endDateTime" }, now] },
                    ],
                  },
                },
              },
              0,
            ],
          },
        },
      },
      {
        $project: {
          _id: 1,
          status: 1,
          lightid: 1,
          location: 1,
          address: 1,
          applyZoneSetting: "$ApplyZoneSetting",
          applyControllingSetting: "$ApplyProfileSetting",
          brightness: {
            $cond: {
              if: { $eq: ["$ApplyZoneSetting", true] },
              then: {
                $cond: {
                  if: { $eq: ["$zoneDetails.isPoweredOn", true] },
                  then: "$zoneDetails.BrightnessLevel",
                  else: {
                    $ifNull: [
                      "$activeDateTime.BrightnessLevel",
                      "$BrightnessLevel",
                    ],
                  },
                },
              },
              else: "$BrightnessLevel",
            },
          },
          isOn: {
            $cond: {
              if: { $eq: ["$ApplyZoneSetting", true] },
              then: {
                $cond: {
                  if: { $eq: ["$zoneDetails.isPoweredOn", true] },
                  then: true,
                  else: false,
                },
              },
              else: "$isPoweredOn",
            },
          },
          dateTimes: 1,
          zone: "$zoneDetails.name",
          zoneId: "$zoneDetails._id",
        },
      },
    ]);

    return res.status(200).json({
      success: true,
      data: lights,
    });
  } catch (error) {
    console.error("Error in getAllLights:", error);
    return res.status(500).json({
      success: false,
      message: "Server error",
      error: error.message,
    });
  }
};

exports.updatePowerStatus = async (req, res) => {
  try {
    const { lightId } = req.params;

    const findLight = await Light.findById(lightId);
    if (!findLight) {
      return res
        .status(404)
        .json({ success: false, message: "Light Not Found" });
    }

    findLight.isPoweredOn = !findLight.isPoweredOn;
    await findLight.save();
    return res.status(200).json({
      success: true,
      message: "Power status updated successfully",
      // data: updatedLight,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      success: false,
      message: "Server error",
      error: error.message,
    });
  }
};

// Light With respect to Zone

exports.getLightsWithZone = async (req, res) => {
  try {
    const { id } = req.params;
    const findLight = await Light.find({ zone: id }).populate("zone");
    return res.status(200).json({ success: true, data: findLight });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};
