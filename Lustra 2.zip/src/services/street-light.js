import { DELETE, GET, PATCH, POST } from "./http-client";

// export const createLight = async (data) => {
//   try {
//     await POST("light/create", data);
//   } catch (error) {
//     console.error("API error:", error);
//   }
// };

export const getAllLights = async () => {
  try {
    return await GET("light/getAll");
  } catch (error) {
    console.error("API error:", error);
  }
};

export const deleteLight = async (id) => {
  try {
    await DELETE(`light/delete/${id}`);
  } catch (error) {
    console.error("API error:", error);
  }
};

export const updateLight = async (id, data) => {
  try {
    await PATCH(`light/update/${id}`, data);
  } catch (error) {
    console.error("API error:", error);
  }
};

export const toggleLight = async (id) => {
  try {
    await PATCH(`light/togglepower/${id}`);
  } catch (error) {
    console.error("API error:", error);
  }
};

export const createControlNode = async (data) => {
  try {
    await POST("controlNode/create", data);
  } catch (error) {
    console.error("Error creating control node:", error);
  }
};

export const changeBrightnessAPI = async (id, brightness) => {
  try {
    await PATCH(`TVILIGHT/brightness/${id}`, { brightness });
    console.log("Brightness updated successfully in TVILIGHT API");
  } catch (error) {
    console.error("API error in changeBrightnessAPI:", error);
  }
};

export const determinePowerStatus = async (dateTimes) => {
  try {
    const response = await POST("controlProfile/brightness", { dateTimes });
    return response.brightnessLevel || 0;
  } catch (error) {
    console.error("API error in determinePowerStatus:", error);
    return 0; // Default brightness on error
  }
};

export const createLight = (data) => POST("light/create", data);
