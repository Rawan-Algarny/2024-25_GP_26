import React, { useState, useCallback } from "react";
import { GoogleMap, useLoadScript, Marker } from "@react-google-maps/api";

const mapContainerStyle = {
  height: "400px",
  width: "100%",
};

const defaultCenter = {
  lat: 24.7136,
  lng: 46.6753,
};

const libraries = ["places"];

function LocationPicker({ onLocationSelect }) {
  const [markerPosition, setMarkerPosition] = useState(null);

  const { isLoaded, loadError } = useLoadScript({
    googleMapsApiKey: "AIzaSyBjCdUh4aafEzIIFmVRoq7i48RNZ0rndhY",
    libraries,
  });

  const onMapClick = useCallback(
    (event) => {
      const position = {
        lat: event.latLng.lat(),
        lng: event.latLng.lng(),
      };
      setMarkerPosition(position);
      onLocationSelect(position);
    },
    [onLocationSelect]
  );

  if (loadError) {
    return <div className="p-4 text-red-500">Error loading maps</div>;
  }

  if (!isLoaded) {
    return <div className="p-4">Loading maps...</div>;
  }

  return (
    <GoogleMap
      mapContainerStyle={mapContainerStyle}
      center={defaultCenter}
      zoom={12}
      onClick={onMapClick}
    >
      {markerPosition && <Marker position={markerPosition} />}
    </GoogleMap>
  );
}

export default React.memo(LocationPicker);
