import PropTypes from "prop-types";
import { GoogleMap, MarkerF } from "@react-google-maps/api";
import React, { memo, useState } from "react";

const styles = {
  container: {
    width: "100%",
    height: "400px",
  },
};

function isCurrentTimeInDateRanges(data) {
  // Get the current time in ISO format
  const currentTime = new Date();

  // Flatten the nested array to simplify processing
  const flattenedData = data.flat();

  // Check if current time is within any of the date ranges
  for (const range of flattenedData) {
    const startDateTime = new Date(range.startDateTime);
    const endDateTime = new Date(range.endDateTime);

    if (currentTime >= startDateTime && currentTime <= endDateTime) {
      return true; // Current time is within this range
    }
  }

  return false; // Current time is not within any range
}

const MapComponent = ({ data, mapCenter }) => {
  const [map, setMap] = useState(null);

  const defaultMapCenter = {
    lat: 24.7136,
    lng: 46.6753,
  };

  const centerToShow = mapCenter || defaultMapCenter;

  const getMarkerIcon = (item) => {
    const baseIcon = {
      scaledSize: new window.google.maps.Size(30, 30),
      origin: new window.google.maps.Point(0, 0),
      anchor: new window.google.maps.Point(15, 15),
    };
    const dateArray = item?.dateTimes?.map((it) => it?.dateTimes);
    if (item?.status === "functioning" && item.isOn) {
      if (isCurrentTimeInDateRanges(dateArray)) {
        return {
          ...baseIcon,
          url: "green.png",
        };
      } else {
        return {
          ...baseIcon,
          url: "/black.png",
        };
      }
    } else if (item?.status === "functioning" && !item.isOn) {
      return {
        ...baseIcon,
        url: "/black.png",
      };
    } else {
      return {
        ...baseIcon,
        url: "red.png",
      };
    }
  };

  return (
    <div className="w-full">
      <div className="w-full">
        <GoogleMap
          onLoad={setMap}
          id="shapes-example"
          mapContainerStyle={styles.container}
          center={centerToShow}
          zoom={14}
        >
          {/* Render markers based on data */}
          {data?.length > 0 &&
            data?.map((item, index) => (
              <MarkerF
                key={index}
                position={{
                  lat: item?.coordinates[1],
                  lng: item?.coordinates[0],
                }}
                icon={getMarkerIcon(item)}
              />
            ))}
        </GoogleMap>
      </div>
    </div>
  );
};

MapComponent.propTypes = {
  data: PropTypes.arrayOf(
    PropTypes.arrayOf(PropTypes.number.isRequired).isRequired
  ).isRequired,
  mapCenter: PropTypes.shape({
    lat: PropTypes.number.isRequired,
    lng: PropTypes.number.isRequired,
  }),
};

export default memo(MapComponent);
