import { DELETE, GET, PATCH, POST } from "./http-client";

export const createLight = async (data) => {
  try {
    await POST("light/create", data);
  } catch (error) {
    console.error("API error:", error);
  }
};

export const getAllLights = async () => {
  try {
    return await GET("light/getAll");
  } catch (error) {
    console.error("API error:", error);
  }
};

export const deleteLight = async (id) => {
  try {
    await DELETE(`light/delete/${id}`);
  } catch (error) {
    console.error("API error:", error);
  }
};

export const updateLight = async (id, data) => {
  try {
    await PATCH(`light/update/${id}`, data);
  } catch (error) {
    console.error("API error:", error);
  }
};

export const toggleLight = async (id) => {
  try {
    await PATCH(`light/togglepower/${id}`);
  } catch (error) {
    console.error("API error:", error);
  }
}