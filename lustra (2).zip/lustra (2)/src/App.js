import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import AllStreetLights from "./components/manageStreetLights/AllStreetLights";
import AddStreetLight from "./components/manageStreetLights/AddStreetLight";
import LightsInfo from "./components/manageStreetLights/LightsInfo";
import UpdateStreetLight from "./components/manageStreetLights/UpdateStreetLight";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

function App() {
  return (
    <div>
      <Router>
        <Routes>
          <Route path="/" element={<AllStreetLights />} />
          <Route path="/add-lights" element={<AddStreetLight />} />
          <Route path="/update-lights" element={<UpdateStreetLight />} />
          <Route path="/lights-info" element={<LightsInfo />} />
        </Routes>
      </Router>
      <ToastContainer></ToastContainer>
    </div>
  );
}

export default App;
