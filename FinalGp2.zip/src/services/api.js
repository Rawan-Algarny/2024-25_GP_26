import axios from "axios";

const api = axios.create({
  baseURL: "https://ctl.tvilight.io/api",
  headers: {
    "Content-Type": "application/json",
    Authorization:
      "Bearer 409dacc5aff3dccf5dbafad7361a3b6dc996d7effcfd2156056e41ffe3c0d514  ",
    ClientId:
      "a6e3558e93c5bbb6d3f29a672b513da51fb7c8bfeaa67d5f9e63f28a434de6d3",
    Accept: "application/vnd.tvilight.v1.0+json",
  },
});

export default api;
