import React, { useEffect, useRef, useState } from "react";
import { NavLink, useLocation } from "react-router-dom";
import logo from "../../assets/images/LOGO-Trans 1.svg";
import Svgs from "../../assets/svgs";

const Sidebar = ({ sidebarOpen, setSidebarOpen }) => {
  const location = useLocation();
  const trigger = useRef(null);
  const sidebar = useRef(null);
  const [showConsumptionDropdown, setShowConsumptionDropdown] = useState(true);

  useEffect(() => {
    const clickHandler = ({ target }) => {
      if (!sidebar.current || !trigger.current) return;
      if (
        !sidebarOpen ||
        sidebar.current.contains(target) ||
        trigger.current.contains(target)
      )
        return;
      setSidebarOpen(false);
    };
    document.addEventListener("click", clickHandler);
    return () => document.removeEventListener("click", clickHandler);
  });

  // Check if a specific section is active
  const isActive = (path) => {
    return location.pathname.includes(path);
  };

  return (
    <aside
      ref={sidebar}
      className={`absolute left-0 top-0 z-40 flex h-screen w-[256px] flex-col overflow-y-auto bg-[#012657] duration-300 ease-linear lg:static lg:translate-x-0 ${
        sidebarOpen ? "translate-x-0" : "-translate-x-full"
      }`}
    >
      <div className="flex flex-col items-center w-full">
        <div className="flex items-center text-white font-bold justify-between gap-2 px-6 py-5 lg:py-4 w-full">
          <img src={logo} alt="logo" />
        </div>

        <div className="flex gap-2 items-center justify-center w-[80%] h-[55px]">
          <p className="font-semibold text-base text-white text-center">
            Welcome Sarah Amir
          </p>
        </div>

        {/* Manage Zone Section */}
        <div className="flex gap-2 items-center justify-center w-full h-[55px] cursor-pointer">
          <p
            className={`font-semibold text-base text-white ${
              (isActive("/all-zone") || isActive("/add-zone")) &&
              !isActive("/analytics")
                ? "bg-[#3B7BD1] px-2 py-1 rounded"
                : ""
            }`}
          >
            Manage Zone
          </p>
          <Svgs.WhiteDropDown />
        </div>
        <div className="relative text-white text-sm w-full">
          <div className="absolute left-[72.5px] top-[-15px] bottom-0 w-[2px] bg-[#3B7BD1] h-[105px]"></div>
          <div className="pl-[4.2rem] pt-2 pb-4 space-y-4 mt-6">
            <div className="flex items-center gap-6">
              <div className="w-[13px] h-[13px] bg-[#3B7BD1] rounded-full"></div>
              <NavLink
                to="/all-zone"
                className={`hover:text-gray-200 w-[116px] h-[14.7px] flex justify-center items-center font-normal text-[10px] text-white rounded-[4px]`}
              >
                All Zone
              </NavLink>
            </div>
            <div className="flex items-center gap-6">
              <div className="w-[13px] h-[13px] bg-[#3B7BD1] rounded-full"></div>
              <NavLink
                to="/add-zone"
                className={`hover:text-gray-200 w-[116px] h-[14.7px] flex justify-center items-center font-normal text-[10px] text-white rounded-[4px]`}
              >
                Add Zone
              </NavLink>
            </div>
          </div>
        </div>

        {/* Manage Streetlight Section */}
        <div className="flex gap-2 items-center justify-center w-full h-[55px] cursor-pointer">
          <Svgs.Globe />
          <p
            className={`font-semibold text-base text-white ${
              (location.pathname === "/" || isActive("/add-lights")) &&
              !isActive("/analytics")
                ? "bg-[#3B7BD1] px-2 py-1 rounded"
                : ""
            }`}
          >
            Manage Streetlight
          </p>
          <Svgs.WhiteDropDown />
        </div>
        <div className="relative text-white text-sm w-full">
          <div className="absolute left-[72.5px] top-[-15px] bottom-0 w-[2px] bg-[#3B7BD1] h-[105px]"></div>
          <div className="pl-[4.2rem] pt-2 pb-4 space-y-4 mt-6">
            <div className="flex items-center gap-6">
              <div className="w-[13px] h-[13px] bg-[#3B7BD1] rounded-full"></div>
              <NavLink
                to="/"
                className={`hover:text-gray-200 w-[116px] h-[14.7px] flex justify-center items-center font-normal text-[10px] text-white rounded-[4px]`}
              >
                All Streetlight
              </NavLink>
            </div>
            <div className="flex items-center gap-6">
              <div className="w-[13px] h-[13px] bg-[#3B7BD1] rounded-full"></div>
              <NavLink
                to="/add-lights"
                className="hover:text-gray-200 w-[116px] h-[14.7px] flex justify-center items-center font-normal text-[10px] text-white rounded-[4px]"
              >
                Add Streetlight
              </NavLink>
            </div>
          </div>
        </div>

        {/* Monitor Motion Events */}
        <div className="flex gap-2 items-center justify-center w-[80%] h-[55px] cursor-pointer text-center">
          <p
            className={`font-semibold text-base text-white ${
              isActive("/motion-events") && !isActive("/analytics")
                ? "bg-[#3B7BD1] px-2 py-1 rounded"
                : ""
            }`}
          >
            Monitor Motion events
          </p>
        </div>

        {/* View Consumption Analytics Report */}
        <div
          className="flex gap-2 items-center justify-center w-full h-[55px] cursor-pointer"
          onClick={() => setShowConsumptionDropdown(!showConsumptionDropdown)}
        >
          <div
            className={`flex gap-2 items-center justify-center w-[80%] ${
              isActive("/analytics") ? "bg-[#3B7BD1] px-2 py-1 rounded" : ""
            }`}
          >
            <p className="font-semibold text-base text-white text-center">
              View Consumption Analytics Report
            </p>
            <Svgs.WhiteDropDown />
          </div>
        </div>

        {showConsumptionDropdown && (
          <div className="relative text-white text-sm w-full">
            <div className="absolute left-[72.5px] top-[-15px] bottom-0 w-[2px] bg-[#3B7BD1] h-[50px]"></div>
            <div className="pl-[4.2rem] pt-2 pb-4 space-y-4 mt-6">
              <div className="flex items-center gap-6">
                <div className="w-[13px] h-[13px] bg-[#3B7BD1] rounded-full"></div>
                <NavLink
                  to="/analytics/streetlight"
                  className={({ isActive }) =>
                    `hover:text-gray-200 w-[116px] h-[14.7px] flex justify-center items-center font-normal text-[10px] text-white rounded-[4px] ${
                      isActive ? "bg-[#3B7BD1]" : "bg-[#3D85E7]"
                    }`
                  }
                >
                  View by Streetlight
                </NavLink>
              </div>
            </div>
          </div>
        )}

        {/* Monitor Fault Notifications */}
        <div className="flex gap-2 items-center justify-center w-[80%] h-[55px] cursor-pointer">
          <p
            className={`font-semibold text-base text-white ${
              isActive("/fault-notifications") && !isActive("/analytics")
                ? "bg-[#3B7BD1] px-2 py-1 rounded"
                : ""
            }`}
          >
            Monitor Fault Notifications
          </p>
        </div>

        {/* Logout Section */}
        <div className="flex items-center justify-center w-full mt-12 mb-6">
          <span className="cursor-pointer">
            <Svgs.Logout />
          </span>
          <p className="font-semibold text-base text-white cursor-pointer">
            Logout
          </p>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
