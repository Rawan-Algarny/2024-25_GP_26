import React, { useState, useEffect } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  BarChart,
  Bar,
} from "recharts";
import Sidebar from "../Sidebar/Sidebar";
import api from "../../services/api";

const ConsumptionAnalytics = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [filterType, setFilterType] = useState("daily");
  const [startDate, setStartDate] = useState("2025-01-01");
  const [endDate, setEndDate] = useState("2025-01-31");
  const [savingsData, setSavingsData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedMetric, setSelectedMetric] = useState("power");
  const [zoneDevices, setZoneDevices] = useState([]);
  const [selectedDeviceId, setSelectedDeviceId] = useState("");

  const zoneId = "7189c143-5e39-4787-949b-e1182e80a613";

  // Fetch devices in the zone
  const fetchZoneDevices = async () => {
    try {
      setLoading(true);
      const response = await api.get(`/groups/${zoneId}/devices`);

      if (response.data && Array.isArray(response.data)) {
        setZoneDevices(response.data);
        // Set the first device as selected by default
        if (response.data.length > 0 && !selectedDeviceId) {
          setSelectedDeviceId(response.data[0].id);
        }
        setLoading(false);
      } else {
        setError("No devices found in this zone");
        setLoading(false);
      }
    } catch (err) {
      console.error("Error fetching zone devices:", err);
      setError("Failed to fetch devices in this zone");
      setLoading(false);
    }
  };

  const fetchSavingsData = async () => {
    if (!selectedDeviceId) return;

    try {
      setLoading(true);
      setError(null);

      // Format dates for API (DD-MM-YYYY)
      const formatDate = (dateStr) => {
        const [year, month, day] = dateStr.split("-");
        return `${day}-${month}-${year}`;
      };

      const formattedStartDate = formatDate(startDate);
      const formattedEndDate = formatDate(endDate);

      const response = await api.get("/savings", {
        params: {
          type: "device",
          q: selectedDeviceId,
          dateFrom: formattedStartDate,
          dateTo: formattedEndDate,
          timeSlice: filterType === "daily" ? "day" : "month",
        },
      });

      if (
        response.data &&
        Array.isArray(response.data) &&
        response.data[0]?.values
      ) {
        const transformedData = response.data[0].values.map((item) => ({
          time: new Date(item.time).toLocaleDateString(),
          value: Number(item.consumption_kwh || 0),
          power: Number(item.saved_kwh || 0),
          duration: Number(item.total_duration || 0),
          savings: Number(item.savings_percentage || 0),
        }));

        setSavingsData(transformedData);
      } else {
        setError("No savings data found");
      }

      setLoading(false);
    } catch (err) {
      console.error("Savings data fetch error:", err);
      setError("Error fetching savings data");
      setLoading(false);
    }
  };

  // Fetch zone devices on component mount
  useEffect(() => {
    fetchZoneDevices();
  }, []);

  // Fetch savings data when device ID, filter type, or dates change
  useEffect(() => {
    if (selectedDeviceId) {
      fetchSavingsData();
    }
  }, [selectedDeviceId, filterType, startDate, endDate]);

  const handleFilterTypeChange = (type) => {
    setFilterType(type);
    if (type === "monthly") {
      setStartDate("2025-01-01");
      setEndDate("2025-12-31");
    } else {
      setStartDate("2025-01-01");
      setEndDate("2025-01-31");
    }
  };

  const handleDeviceChange = (e) => {
    setSelectedDeviceId(e.target.value);
  };

  const handleMetricChange = (e) => {
    setSelectedMetric(e.target.value);
  };

  // Get the appropriate label for the selected metric
  const getMetricLabel = () => {
    switch (selectedMetric) {
      case "power":
        return "Power Savings Trend (kWh)";
      case "value":
        return "Energy Consumption (kWh)";
      case "savings":
        return "Savings Percentage (%)";
      default:
        return "Power Savings Trend (kWh)";
    }
  };

  // Get the appropriate color for the selected metric
  const getMetricColor = () => {
    switch (selectedMetric) {
      case "power":
        return "#3D85E7";
      case "value":
        return "#3D85E7";
      case "savings":
        return "#28a745";
      default:
        return "#3D85E7";
    }
  };

  // Get the appropriate chart type for the selected metric
  const getChartType = () => {
    switch (selectedMetric) {
      case "power":
        return "line";
      case "value":
        return "bar";
      case "savings":
        return "line";
      default:
        return "line";
    }
  };

  // Get the appropriate Y-axis domain for the selected metric
  const getYAxisDomain = () => {
    if (selectedMetric === "savings") {
      return [0, 100];
    }
    return [0, "auto"];
  };

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} />

      <div className="relative flex flex-1 flex-col overflow-y-auto overflow-x-hidden">
        <main>
          <div className="mx-auto max-w-screen-2xl p-4 md:p-6 2xl:p-10">
            <div className="bg-white rounded-lg p-6 shadow-md">
              <div className="flex justify-between items-center mb-6">
                <h1 className="text-2xl font-semibold">
                  View Consumption Analytics by Streetlight
                </h1>
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <label className="text-sm font-medium">from</label>
                    <input
                      type="date"
                      className="border rounded px-3 py-1"
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                    />
                    <label className="text-sm font-medium">to</label>
                    <input
                      type="date"
                      className="border rounded px-3 py-1"
                      value={endDate}
                      onChange={(e) => setEndDate(e.target.value)}
                    />
                    <label className="text-sm font-medium">by</label>
                    <select
                      className="border rounded px-3 py-1"
                      value={filterType}
                      onChange={(e) => handleFilterTypeChange(e.target.value)}
                    >
                      <option value="daily">Day</option>
                      <option value="monthly">Month</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Device Selection Dropdown */}
              <div className="mb-6">
                <div className="flex items-center gap-2">
                  <label className="text-sm font-medium">
                    Select Streetlight:
                  </label>
                  <select
                    className="border rounded px-3 py-1 min-w-[300px]"
                    value={selectedDeviceId}
                    onChange={handleDeviceChange}
                  >
                    {zoneDevices.map((device) => (
                      <option key={device.id} value={device.id}>
                        {device.id}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Metric Selection Dropdown */}
              <div className="mb-6">
                <div className="flex items-center gap-2">
                  <label className="text-sm font-medium">Select Metric:</label>
                  <select
                    className="border rounded px-3 py-1"
                    value={selectedMetric}
                    onChange={handleMetricChange}
                  >
                    <option value="power">Power Savings Trend (kWh)</option>
                    <option value="value">Energy Consumption (kWh)</option>
                    <option value="savings">Savings Percentage (%)</option>
                  </select>
                </div>
              </div>

              <div className="mb-6">
                {loading ? (
                  <div className="text-center py-4">Loading...</div>
                ) : error ? (
                  <div className="text-center text-red-500 py-4">{error}</div>
                ) : (
                  <>
                    {/* Dynamic Chart based on selected metric */}
                    <div className="mb-8">
                      <h3 className="text-lg font-medium mb-2">
                        {getMetricLabel()}
                      </h3>
                      {getChartType() === "line" ? (
                        <LineChart width={1000} height={300} data={savingsData}>
                          <CartesianGrid
                            strokeDasharray="3 3"
                            vertical={false}
                          />
                          <XAxis
                            dataKey="time"
                            height={60}
                            interval="preserveStartEnd"
                            tick={{ fontSize: 12 }}
                            angle={-45}
                            textAnchor="end"
                          />
                          <YAxis domain={getYAxisDomain()} />
                          <Tooltip />
                          <Line
                            type="monotone"
                            dataKey={selectedMetric}
                            name={getMetricLabel()}
                            stroke={getMetricColor()}
                            strokeWidth={2}
                            dot={{ r: 4 }}
                          />
                        </LineChart>
                      ) : (
                        <BarChart width={1000} height={300} data={savingsData}>
                          <CartesianGrid
                            strokeDasharray="3 3"
                            vertical={false}
                          />
                          <XAxis
                            dataKey="time"
                            height={60}
                            interval="preserveStartEnd"
                            tick={{ fontSize: 12 }}
                            angle={-45}
                            textAnchor="end"
                          />
                          <YAxis domain={getYAxisDomain()} />
                          <Tooltip />
                          <Bar
                            dataKey={selectedMetric}
                            name={getMetricLabel()}
                            fill={getMetricColor()}
                            radius={[4, 4, 0, 0]}
                          />
                        </BarChart>
                      )}
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default ConsumptionAnalytics;
