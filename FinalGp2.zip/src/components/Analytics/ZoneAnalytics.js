import React, { useState, useEffect } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  BarChart,
  Bar,
} from "recharts";
import Sidebar from "../Sidebar/Sidebar";
import api from "../../services/api";

const ZoneAnalytics = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [filterType, setFilterType] = useState("daily");
  const [startDate, setStartDate] = useState("2025-01-01");
  const [endDate, setEndDate] = useState("2025-01-31");
  const [zoneDevices, setZoneDevices] = useState([]);
  const [combinedData, setCombinedData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedMetric, setSelectedMetric] = useState("savings");

  const zoneId = "7189c143-5e39-4787-949b-e1182e80a613";

  // Fetch devices in the zone
  const fetchZoneDevices = async () => {
    try {
      setLoading(true);
      const response = await api.get(`/groups/${zoneId}/devices`);

      if (response.data && Array.isArray(response.data)) {
        setZoneDevices(response.data);
        return response.data;
      } else {
        setError("No devices found in this zone");
        setLoading(false);
        return [];
      }
    } catch (err) {
      console.error("Error fetching zone devices:", err);
      setError("Failed to fetch devices in this zone");
      setLoading(false);
      return [];
    }
  };

  // Fetch savings data for a specific device
  const fetchDeviceSavingsData = async (deviceId) => {
    try {
      // Format dates for API (DD-MM-YYYY)
      const formatDate = (dateStr) => {
        const [year, month, day] = dateStr.split("-");
        return `${day}-${month}-${year}`;
      };

      const formattedStartDate = formatDate(startDate);
      const formattedEndDate = formatDate(endDate);

      const response = await api.get("/savings", {
        params: {
          type: "device",
          q: deviceId,
          dateFrom: formattedStartDate,
          dateTo: formattedEndDate,
          timeSlice: filterType === "daily" ? "day" : "month",
        },
      });

      if (
        response.data &&
        Array.isArray(response.data) &&
        response.data[0]?.values
      ) {
        return response.data[0].values.map((item) => ({
          deviceId: deviceId,
          time: new Date(item.time).toLocaleDateString(),
          value: Number(item.consumption_kwh || 0),
          power: Number(item.saved_kwh || 0),
          savings: Number(item.savings_percentage || 0),
        }));
      }
      return [];
    } catch (err) {
      console.error(`Error fetching savings data for device ${deviceId}:`, err);
      return [];
    }
  };

  // Fetch metering data for a specific device
  const fetchDeviceMeteringData = async (deviceId) => {
    try {
      const response = await api.get(
        `/drivers/${deviceId}/dynamic_meterings/`,
        {
          params: {
            start_date: startDate,
            end_date: endDate,
          },
        }
      );

      if (
        response.data &&
        Array.isArray(response.data) &&
        response.data.length > 0
      ) {
        return response.data.map((item) => ({
          deviceId: deviceId,
          time: new Date(item.received_at).toLocaleDateString(),
          input_voltage: Number(item.input_voltage || 0),
          active_energy: Number(item.active_energy || 0),
          power_factor: Number(item.power_factor || 0),
        }));
      }
      return [];
    } catch (err) {
      console.error(
        `Error fetching metering data for device ${deviceId}:`,
        err
      );
      return [];
    }
  };

  // Combine data from multiple devices
  const combineData = (allDevicesData) => {
    // Create a map to store combined data by date
    const dataByDate = new Map();

    // Process all device data
    allDevicesData.forEach((deviceData) => {
      deviceData.forEach((item) => {
        if (!dataByDate.has(item.time)) {
          dataByDate.set(item.time, {
            time: item.time,
            value: 0,
            power: 0,
            savings: 0,
            input_voltage: 0,
            active_energy: 0,
            power_factor: 0,
            deviceCount: 0,
          });
        }

        const existingData = dataByDate.get(item.time);
        dataByDate.set(item.time, {
          ...existingData,
          value: existingData.value + (item.value || 0),
          power: existingData.power + (item.power || 0),
          savings: existingData.savings + (item.savings || 0),
          input_voltage: existingData.input_voltage + (item.input_voltage || 0),
          active_energy: existingData.active_energy + (item.active_energy || 0),
          power_factor: existingData.power_factor + (item.power_factor || 0),
          deviceCount: existingData.deviceCount + 1,
        });
      });
    });

    // Calculate averages for metrics that should be averaged (like voltage and savings percentage)
    const result = Array.from(dataByDate.values()).map((item) => {
      if (item.deviceCount > 0) {
        return {
          ...item,
          savings: item.savings / item.deviceCount,
          input_voltage: item.input_voltage / item.deviceCount,
          power_factor: item.power_factor / item.deviceCount,
        };
      }
      return item;
    });

    // Sort by date
    return result.sort((a, b) => new Date(a.time) - new Date(b.time));
  };

  // Fetch all data
  const fetchAllData = async () => {
    try {
      setLoading(true);
      setError(null);

      // First, get all devices in the zone
      const devices = await fetchZoneDevices();

      if (devices.length === 0) {
        setLoading(false);
        return;
      }

      // Fetch both savings and metering data for all devices
      const savingsData = [];
      const meteringData = [];

      // Fetch savings data for all devices
      for (const device of devices) {
        const deviceSavingsData = await fetchDeviceSavingsData(device.id);
        if (deviceSavingsData.length > 0) {
          savingsData.push(deviceSavingsData);
        }

        const deviceMeteringData = await fetchDeviceMeteringData(device.id);
        if (deviceMeteringData.length > 0) {
          meteringData.push(deviceMeteringData);
        }
      }

      // Combine data from all devices
      const combinedSavingsData = combineData(savingsData);
      const combinedMeteringData = combineData(meteringData);

      // Merge the two datasets by date
      const mergedData = mergeDatasets(
        combinedSavingsData,
        combinedMeteringData
      );

      setCombinedData(mergedData);

      setLoading(false);
    } catch (err) {
      console.error("Error fetching all data:", err);
      setError("Failed to fetch data");
      setLoading(false);
    }
  };

  // Add a function to merge the two datasets
  const mergeDatasets = (savingsData, meteringData) => {
    const dataMap = new Map();

    // Add savings data to the map
    savingsData.forEach((item) => {
      dataMap.set(item.time, {
        time: item.time,
        value: item.value || 0,
        power: item.power || 0,
        savings: item.savings || 0,
        input_voltage: 0,
        active_energy: 0,
        power_factor: 0,
      });
    });

    // Merge metering data
    meteringData.forEach((item) => {
      if (dataMap.has(item.time)) {
        const existing = dataMap.get(item.time);
        dataMap.set(item.time, {
          ...existing,
          input_voltage: item.input_voltage || 0,
          active_energy: item.active_energy || 0,
          power_factor: item.power_factor || 0,
        });
      } else {
        dataMap.set(item.time, {
          time: item.time,
          value: 0,
          power: 0,
          savings: 0,
          input_voltage: item.input_voltage || 0,
          active_energy: item.active_energy || 0,
          power_factor: item.power_factor || 0,
        });
      }
    });

    // Convert map to array and sort by date
    return Array.from(dataMap.values()).sort(
      (a, b) => new Date(a.time) - new Date(b.time)
    );
  };

  // Fetch data on component mount and when filters change
  useEffect(() => {
    fetchAllData();
  }, [filterType, startDate, endDate, selectedMetric]);

  const handleFilterTypeChange = (type) => {
    setFilterType(type);
    if (type === "monthly") {
      setStartDate("2025-01-01");
      setEndDate("2025-12-31");
    } else {
      setStartDate("2025-01-01");
      setEndDate("2025-01-31");
    }
  };

  // Get the appropriate label for the selected metric
  const getMetricLabel = () => {
    switch (selectedMetric) {
      case "input_voltage":
        return "Input Voltage (V)";
      case "active_energy":
        return "Active Energy (kWh)";
      case "power_factor":
        return "Power Factor";
      case "savings":
        return "Savings";
      default:
        return "Active Energy (kWh)";
    }
  };

  // Get the appropriate color for the selected metric
  const getMetricColor = () => {
    switch (selectedMetric) {
      case "input_voltage":
        return "#FF4B6E";
      case "active_energy":
        return "#3D85E7";
      case "power_factor":
        return "#FFA500";
      case "savings":
        return "#28a745";
      default:
        return "#3D85E7";
    }
  };

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} />

      <div className="relative flex flex-1 flex-col overflow-y-auto overflow-x-hidden">
        <main>
          <div className="mx-auto max-w-screen-2xl p-4 md:p-6 2xl:p-10">
            <div className="bg-white rounded-lg p-6 shadow-md">
              <div className="flex justify-between items-center mb-6">
                <h1 className="text-2xl font-semibold">
                  View Consumption Analytics by Zone
                </h1>
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <label className="text-sm font-medium">Zone ID:</label>
                    <input
                      type="text"
                      value={zoneId}
                      className="border rounded px-3 py-1"
                      readOnly
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <label className="text-sm font-medium">from</label>
                    <input
                      type="date"
                      className="border rounded px-3 py-1"
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                    />
                    <label className="text-sm font-medium">to</label>
                    <input
                      type="date"
                      className="border rounded px-3 py-1"
                      value={endDate}
                      onChange={(e) => setEndDate(e.target.value)}
                    />
                    <label className="text-sm font-medium">by</label>
                    <select
                      className="border rounded px-3 py-1"
                      value={filterType}
                      onChange={(e) => handleFilterTypeChange(e.target.value)}
                    >
                      <option value="daily">Day</option>
                      <option value="monthly">Month</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Metric Selection Dropdown */}
              <div className="mb-6">
                <div className="flex items-center gap-2">
                  <label className="text-sm font-medium">Select Metric:</label>
                  <select
                    className="border rounded px-3 py-1"
                    value={selectedMetric}
                    onChange={(e) => setSelectedMetric(e.target.value)}
                  >
                    <option value="savings">Savings</option>
                    <option value="active_energy">Active Energy</option>
                    <option value="input_voltage">Input Voltage</option>
                    <option value="power_factor">Power Factor</option>
                  </select>
                </div>
              </div>

              {/* Device Count Info */}
              <div className="mb-6">
                <p className="text-sm text-gray-600">
                  Showing combined data for {zoneDevices.length} devices in this
                  zone
                </p>
              </div>

              <div className="mb-6">
                {loading ? (
                  <div className="text-center py-4">Loading...</div>
                ) : error ? (
                  <div className="text-center text-red-500 py-4">{error}</div>
                ) : (
                  <>
                    {selectedMetric === "savings" ? (
                      // Savings Charts
                      <>
                        {/* Power Savings Trend Chart */}
                        <div className="mb-8">
                          <h3 className="text-lg font-medium mb-2">
                            Zone Power Savings Trend (kWh)
                          </h3>
                          <LineChart
                            width={1000}
                            height={300}
                            data={combinedData}
                          >
                            <CartesianGrid
                              strokeDasharray="3 3"
                              vertical={false}
                            />
                            <XAxis
                              dataKey="time"
                              height={60}
                              interval="preserveStartEnd"
                              tick={{ fontSize: 12 }}
                              angle={-45}
                              textAnchor="end"
                            />
                            <YAxis />
                            <Tooltip />
                            <Line
                              type="monotone"
                              dataKey="power"
                              name="Saved Power (kWh)"
                              stroke="#3D85E7"
                              strokeWidth={2}
                              dot={{ r: 4 }}
                            />
                          </LineChart>
                        </div>

                        {/* Energy Consumption Bar Chart */}
                        <div className="mb-8">
                          <h3 className="text-lg font-medium mb-2">
                            Zone Energy Consumption (kWh)
                          </h3>
                          <BarChart
                            width={1000}
                            height={300}
                            data={combinedData}
                          >
                            <CartesianGrid
                              strokeDasharray="3 3"
                              vertical={false}
                            />
                            <XAxis
                              dataKey="time"
                              height={60}
                              interval="preserveStartEnd"
                              tick={{ fontSize: 12 }}
                              angle={-45}
                              textAnchor="end"
                            />
                            <YAxis />
                            <Tooltip />
                            <Bar
                              dataKey="value"
                              name="Consumption (kWh)"
                              fill="#3D85E7"
                              radius={[4, 4, 0, 0]}
                            />
                          </BarChart>
                        </div>

                        {/* Savings Percentage Chart */}
                        <div className="mb-8">
                          <h3 className="text-lg font-medium mb-2">
                            Zone Average Savings Percentage (%)
                          </h3>
                          <LineChart
                            width={1000}
                            height={300}
                            data={combinedData}
                          >
                            <CartesianGrid
                              strokeDasharray="3 3"
                              vertical={false}
                            />
                            <XAxis
                              dataKey="time"
                              height={60}
                              interval="preserveStartEnd"
                              tick={{ fontSize: 12 }}
                              angle={-45}
                              textAnchor="end"
                            />
                            <YAxis domain={[0, 100]} />
                            <Tooltip />
                            <Line
                              type="monotone"
                              dataKey="savings"
                              name="Savings %"
                              stroke="#28a745"
                              strokeWidth={2}
                              dot={{ r: 4 }}
                            />
                          </LineChart>
                        </div>
                      </>
                    ) : (
                      // Dynamic Meterings Charts
                      <>
                        {/* Line Chart for selected metric */}
                        <div className="mb-8">
                          <h3 className="text-lg font-medium mb-2">
                            Zone {getMetricLabel()} - Line Chart
                          </h3>
                          <LineChart
                            width={1000}
                            height={300}
                            data={combinedData}
                          >
                            <CartesianGrid
                              strokeDasharray="3 3"
                              vertical={false}
                            />
                            <XAxis
                              dataKey="time"
                              height={60}
                              interval="preserveStartEnd"
                              tick={{ fontSize: 12 }}
                              angle={-45}
                              textAnchor="end"
                            />
                            <YAxis />
                            <Tooltip />
                            <Line
                              type="monotone"
                              dataKey={selectedMetric}
                              name={getMetricLabel()}
                              stroke={getMetricColor()}
                              strokeWidth={2}
                              dot={{ r: 4 }}
                            />
                          </LineChart>
                        </div>

                        {/* Bar Chart for selected metric */}
                        <div className="mb-8">
                          <h3 className="text-lg font-medium mb-2">
                            Zone {getMetricLabel()} - Bar Chart
                          </h3>
                          <BarChart
                            width={1000}
                            height={300}
                            data={combinedData}
                          >
                            <CartesianGrid
                              strokeDasharray="3 3"
                              vertical={false}
                            />
                            <XAxis
                              dataKey="time"
                              height={60}
                              interval="preserveStartEnd"
                              tick={{ fontSize: 12 }}
                              angle={-45}
                              textAnchor="end"
                            />
                            <YAxis />
                            <Tooltip />
                            <Bar
                              dataKey={selectedMetric}
                              name={getMetricLabel()}
                              fill={getMetricColor()}
                              radius={[4, 4, 0, 0]}
                            />
                          </BarChart>
                        </div>
                      </>
                    )}
                  </>
                )}
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default ZoneAnalytics;
