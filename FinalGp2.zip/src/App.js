import React from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import ConsumptionAnalytics from "./components/Analytics/ConsumptionAnalytics";
import ZoneAnalytics from "./components/Analytics/ZoneAnalytics";

function App() {
  return (
    <Router>
      <Routes>
        {/* Redirect root path to /analytics/streetlight */}
        <Route path="/" element={<Navigate to="/analytics/streetlight" replace />} />
        
        {/* Redirect /analytics to /analytics/streetlight */}
        <Route path="/analytics" element={<Navigate to="/analytics/streetlight" replace />} />
        
        {/* Analytics routes */}
        <Route path="/analytics/streetlight" element={<ConsumptionAnalytics />} />
        <Route path="/analytics/zone" element={<ZoneAnalytics />} />
      </Routes>
    </Router>
  );
}

export default App;
